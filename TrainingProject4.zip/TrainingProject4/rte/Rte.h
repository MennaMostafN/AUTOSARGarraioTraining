#ifndef RTE_H_
#define RTE_H_


#include "Rte_Type.h"


#ifdef RTE_CDD_SWC_1_H_

#endif


#ifdef RTE_DECISION_SWC_H_
Std_ReturnType Rte_IRead_sendOrder_Element_1_isClockWise_decision_application_swc_composition_receiver_Decision_SWC_Runnable_1 (variable_isClockWise* data);

#endif


#ifdef RTE_READ_DATA_SWC_H_
Std_ReturnType Rte_Write_read_application_swc_composition_sender_sendOrder_Element_1_isClockWise(variable_isClockWise data);
Std_ReturnType Rte_Write_read_application_swc_composition_sender_sendOrder_Element_2_readData(variable_readData data);

#endif


#ifdef RTE_TOP_LEVEL_COMPOSITION_H_

#endif





#endif
